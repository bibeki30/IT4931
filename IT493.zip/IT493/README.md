# Inventory Management, Product Ordering and Ticketing System

School Project