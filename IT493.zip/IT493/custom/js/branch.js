var manageBranchTable;

$(document).ready(function() {
	// top bar active
	$('#navBranch').addClass('active');
	
	// manage branch table
	manageBranchTable = $("#manageBranchTable").DataTable({
		'ajax': 'php_action/fetchBranch.php',
		'order': []		
	});

	// submit branch form function
	$("#submitBranchForm").unbind('submit').bind('submit', function() {
		// remove the error text
		$(".text-danger").remove();
		// remove the form error
		$('.form-group').removeClass('has-error').removeClass('has-success');			

		var branchName = $("#branchName").val();
		var branchStatus = $("#branchStatus").val();

		if(branchName == "") {
			$("#branchName").after('<p class="text-danger">Branch Name field is required</p>');
			$('#branchName').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#branchName").find('.text-danger').remove();
			// success out for form 
			$("#branchName").closest('.form-group').addClass('has-success');	  	
		}

		if(branchStatus == "") {
			$("#branchStatus").after('<p class="text-danger">Branch Name field is required</p>');
			$('#branchStatus').closest('.form-group').addClass('has-error');
		} else {
			// remov error text field
			$("#branchStatus").find('.text-danger').remove();
			// success out for form 
			$("#branchStatus").closest('.form-group').addClass('has-success');	  	
		}

		if(branchName && branchStatus) {
			var form = $(this);
			// button loading
			$("#createBranchBtn").button('loading');

			$.ajax({
				url : form.attr('action'),
				type: form.attr('method'),
				data: form.serialize(),
				dataType: 'json',
				success:function(response) {
					// button loading
					$("#createBranchBtn").button('reset');

					if(response.success == true) {
						// reload the manage member table 
						manageBranchTable.ajax.reload(null, false);						

  	  			// reset the form text
						$("#submitBranchForm")[0].reset();
						// remove the error text
						$(".text-danger").remove();
						// remove the form error
						$('.form-group').removeClass('has-error').removeClass('has-success');
  	  			
  	  			$('#add-branch-messages').html('<div class="alert alert-success">'+
            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
          '</div>');

  	  			$(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						}); // /.alert
					}  // if

				} // /success
			}); // /ajax	
		} // if

		return false;
	}); // /submit branch form function

});

function editBranchs(branchId = null) {
	if(branchId) {
		// remove hidden branch id text
		$('#branchId').remove();

		// remove the error 
		$('.text-danger').remove();
		// remove the form-error
		$('.form-group').removeClass('has-error').removeClass('has-success');

		// modal loading
		$('.modal-loading').removeClass('div-hide');
		// modal result
		$('.edit-branch-result').addClass('div-hide');
		// modal footer
		$('.editBranchFooter').addClass('div-hide');

		$.ajax({
			url: 'php_action/fetchSelectedBranch.php',
			type: 'post',
			data: {branchId : branchId},
			dataType: 'json',
			success:function(response) {
				// modal loading
				$('.modal-loading').addClass('div-hide');
				// modal result
				$('.edit-branch-result').removeClass('div-hide');
				// modal footer
				$('.editBranchFooter').removeClass('div-hide');

				// setting the branch name value 
				$('#editBranchName').val(response.branch_name);
				// setting the branch status value
				$('#editBranchStatus').val(response.branch_active);
				// branch id 
				$(".editBranchFooter").after('<input type="hidden" name="branchId" id="branchId" value="'+response.branch_id+'" />');

				// update branch form 
				$('#editBranchForm').unbind('submit').bind('submit', function() {

					// remove the error text
					$(".text-danger").remove();
					// remove the form error
					$('.form-group').removeClass('has-error').removeClass('has-success');			

					var branchName = $('#editBranchName').val();
					var branchStatus = $('#editBranchStatus').val();

					if(branchName == "") {
						$("#editBranchName").after('<p class="text-danger">Branch Name field is required</p>');
						$('#editBranchName').closest('.form-group').addClass('has-error');
					} else {
						// remov error text field
						$("#editBranchName").find('.text-danger').remove();
						// success out for form 
						$("#editBranchName").closest('.form-group').addClass('has-success');	  	
					}

					if(branchStatus == "") {
						$("#editBranchStatus").after('<p class="text-danger">Branch Name field is required</p>');

						$('#editBranchStatus').closest('.form-group').addClass('has-error');
					} else {
						// remove error text field
						$("#editBranchStatus").find('.text-danger').remove();
						// success out for form 
						$("#editBranchStatus").closest('.form-group').addClass('has-success');	  	
					}

					if(branchName && branchStatus) {
						var form = $(this);

						// submit btn
						$('#editBranchBtn').button('loading');

						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success:function(response) {

								if(response.success == true) {
									console.log(response);
									// submit btn
									$('#editBranchBtn').button('reset');

									// reload the manage member table 
									manageBranchTable.ajax.reload(null, false);								  	  										
									// remove the error text
									$(".text-danger").remove();
									// remove the form error
									$('.form-group').removeClass('has-error').removeClass('has-success');
			  	  			
			  	  			$('#edit-branch-messages').html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
			          '</div>');

			  	  			$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); // /.alert
								} // /if
									
							}// /success
						});	 // /ajax												
					} // /if

					return false;
				}); // /update branch form

			} // /success
		}); // ajax function

	} else {
		alert('error!! Refresh the page again');
	}
} // /edit branchs function

function removeBranchs(branchId = null) {
	if(branchId) {
		$('#removeBranchId').remove();
		$.ajax({
			url: 'php_action/fetchSelectedBranch.php',
			type: 'post',
			data: {branchId : branchId},
			dataType: 'json',
			success:function(response) {
				$('.removeBranchFooter').after('<input type="hidden" name="removeBranchId" id="removeBranchId" value="'+response.branch_id+'" /> ');

				// click on remove button to remove the branch
				$("#removeBranchBtn").unbind('click').bind('click', function() {
					// button loading
					$("#removeBranchBtn").button('loading');

					$.ajax({
						url: 'php_action/removeBranch.php',
						type: 'post',
						data: {branchId : branchId},
						dataType: 'json',
						success:function(response) {
							console.log(response);
							// button loading
							$("#removeBranchBtn").button('reset');
							if(response.success == true) {

								// hide the remove modal 
								$('#removeMemberModal').modal('hide');

								// reload the branch table 
								manageBranchTable.ajax.reload(null, false);
								
								$('.remove-messages').html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
			          '</div>');

			  	  			$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); // /.alert
							} else {

							} // /else
						} // /response messages
					}); // /ajax function to remove the branch

				}); // /click on remove button to remove the branch

			} // /success
		}); // /ajax

		$('.removeBranchFooter').after();
	} else {
		alert('error!! Refresh the page again');
	}
} // /remove branchs function