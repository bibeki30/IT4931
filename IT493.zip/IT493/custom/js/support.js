$(document).ready(function () {
	// top nav bar 
	$('#navSupport').addClass('active');
}); // document.ready fucntion