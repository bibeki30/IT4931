-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2022 at 07:16 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `store`
--
CREATE DATABASE IF NOT EXISTS `store` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `store`;

-- --------------------------------------------------------

--
-- Table structure for table `branchs`
--

CREATE TABLE `branchs` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `branch_active` int(11) NOT NULL DEFAULT 0,
  `branch_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branchs`
--

INSERT INTO `branchs` (`branch_id`, `branch_name`, `branch_active`, `branch_status`) VALUES
(1, '1', 1, 2),
(2, 'Virginia', 1, 1),
(3, 'Maryland', 1, 1),
(4, 'Pennsylvania', 1, 1),
(5, 'HQ', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL,
  `categories_name` varchar(255) NOT NULL,
  `categories_active` int(11) NOT NULL DEFAULT 0,
  `categories_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`categories_id`, `categories_name`, `categories_active`, `categories_status`) VALUES
(1, 'Furniture', 1, 1),
(2, 'Office Supplies', 1, 1),
(3, 'Lab Supplies', 1, 1),
(4, 'Site Equipment', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `client_contact` varchar(255) NOT NULL,
  `sub_total` varchar(255) NOT NULL,
  `vat` varchar(255) NOT NULL,
  `total_amount` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `grand_total` varchar(255) NOT NULL,
  `paid` varchar(255) NOT NULL,
  `due` varchar(255) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `payment_status` int(11) NOT NULL,
  `payment_place` int(11) NOT NULL,
  `gstn` varchar(255) NOT NULL,
  `order_status` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `client_name`, `client_contact`, `sub_total`, `vat`, `total_amount`, `discount`, `grand_total`, `paid`, `due`, `payment_type`, `payment_status`, `payment_place`, `gstn`, `order_status`, `user_id`, `branch_id`) VALUES
(1, '2022-08-18', '', '', '', '', '', '', '', '', '', 0, 1, 0, '', 1, 1, 5),
(2, '2022-08-20', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 1, 11, 2),
(3, '2022-08-31', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 1, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT 0,
  `product_id` int(11) NOT NULL DEFAULT 0,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `order_item_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `order_id`, `product_id`, `quantity`, `rate`, `total`, `order_item_status`) VALUES
(1, 1, 2, '1', '', '', 1),
(2, 2, 1, '1', '', '', 1),
(3, 3, 8, '1', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_image`, `branch_id`, `categories_id`, `quantity`, `rate`, `active`, `status`) VALUES
(2, 'CASA Study Desk 35\"', '', 5, 1, '1', '1', 1, 1),
(3, 'SAFCO Napoli Recept Desk', '', 5, 1, '1', '1', 1, 1),
(4, 'Claude Monet Painting', '', 5, 1, '1', '1', 1, 1),
(5, 'Insignia Monitor', '', 5, 1, '1', '1', 1, 1),
(6, 'AOC Monitor', '', 5, 1, '1', '1', 1, 1),
(7, 'Clean Hands Helper Portable Sink (A)', '', 5, 1, '1', '1', 1, 1),
(8, 'Clean Hands Helper Portable Sink (B)', '', 5, 1, '0', '1', 1, 1),
(9, 'SAFCO ACDBLK Center Drawer', '', 5, 1, '1', '1', 1, 1),
(10, 'Fischer Brand 25ml Disposable Serological Pipet', '', 5, 1, '1', '1', 1, 1),
(11, 'RNase-free 50 ml Conical Tubes ( Bagged)', '', 5, 1, '1', '1', 1, 1),
(12, 'Comfee Microwave Oven', '', 5, 1, '1', '1', 1, 1),
(13, 'Dynarex Tincture of Green Soap U.S.FP (1 gallon)', '', 5, 1, '1', '1', 1, 1),
(14, 'Personic Healthcare Reserved Patient Parking Sign', '', 5, 1, '1', '1', 1, 1),
(15, 'Lifetime Folding Table', '', 5, 1, '1', '1', 1, 1),
(16, 'PDG Folding Table', '', 5, 1, '1', '1', 1, 1),
(17, 'Snow Joe Shovelution 18\"', '', 5, 1, '1', '1', 1, 1),
(18, 'Loose Bubble Wrap', '', 5, 1, '1', '1', 1, 1),
(19, 'Rubbermaid 23 gal. Step-On Container', '', 5, 1, '1', '1', 1, 1),
(20, 'ULINE Ice Melt 40 lb Pail', '', 5, 1, '1', '1', 1, 1),
(21, 'ULINE Ice Melt 60 lb Bag', '', 5, 1, '1', '1', 1, 1),
(22, 'Labcon Sterile Aerosol Pipet Tips with Extended Length', '', 5, 1, '1', '1', 1, 1),
(23, 'Orange Traffic Cones', '', 5, 1, '1', '1', 1, 1),
(24, 'Yaktrax Boot Scrubber', '', 5, 1, '1', '1', 1, 1),
(25, 'Privacy Screen', '', 5, 1, '1', '1', 1, 1),
(26, 'Intertek Fan-Forced Heater', '', 5, 4, '1', '1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `uniqid` varchar(20) NOT NULL,
  `user` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `init_msg` text NOT NULL,
  `branch` int(11) NOT NULL,
  `date` varchar(250) NOT NULL,
  `last_reply` int(11) NOT NULL,
  `user_read` int(11) NOT NULL,
  `admin_read` int(11) NOT NULL,
  `resolved` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `uniqid`, `user`, `title`, `init_msg`, `branch`, `date`, `last_reply`, `user_read`, `admin_read`, `resolved`) VALUES
(1, '617181b83c1e7', 1, 'System is not working', 'System is not working', 4, '1634828728', 1, 1, 0, 1),
(2, '61718394c0ad5', 12, 'There are some issue!!!!', 'There are some issue!!', 5, '1634829204', 2, 1, 0, 1),
(3, '617bfaa5ce86d', 1, 'zfsafsaf', 'zfsafsaf', 2, '1635515045', 1, 1, 0, 1),
(4, '617bfc35a93af', 11, 'There some glitches', 'There some glitches', 3, '1635515445', 2, 1, 1, 1),
(5, '617c0a73661fd', 1, 'there are secirty glitches!!!', 'there are secirty glitches', 4, '1635519091', 1, 1, 1, 0),
(6, '617c0ba6d462b', 12, 'there some issues', 'there some issues', 5, '1635519398', 1, 1, 0, 0),
(7, '630a7ffe5bbd5', 1, '123', '123', 4, '1661632510', 1, 0, 0, 0),
(8, '630a82335638f', 1, 'test', 'teste2', 5, '1661633075', 1, 0, 0, 0),
(9, '630a860351b15', 1, 'test', 'test', 5, '1661634051', 1, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_replies`
--

CREATE TABLE `ticket_replies` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `text` text NOT NULL,
  `ticket_id` text NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_replies`
--

INSERT INTO `ticket_replies` (`id`, `user`, `text`, `ticket_id`, `date`) VALUES
(1, 1, 'This is fixed', '1', '1634829030'),
(2, 1, 'Please check it.', '1', '1634829129'),
(3, 1, 'The issue is fixed, you can check at your end. Thanks', '2', '1634829404'),
(4, 2, 'fixed', '2', '1635515403'),
(5, 2, 'this is fixed!', '4', '1635517083'),
(6, 1, 'I am looking into this', '5', '1635519340'),
(7, 2, 'ewtewt', '6', '1635519418'),
(8, 1, 'www', '3', '1635519418'),
(9, 1, 'aaa', '3', '1661531191'),
(10, 1, 'trest', '6', '1661531432'),
(11, 1, 'trest', '6', '1661531699'),
(12, 1, 'ddd', '6', '1661531705'),
(13, 1, 'ww', '1', '1661532196'),
(14, 1, '123', '1', '1661631543'),
(15, 1, 'ded', '9', '1661634372');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `manager` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `branch_id`, `manager`, `name`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'test@test.com', 5, 1, 'Josef'),
(11, 'Virginia', '21232f297a57a5a743894a0e4a801fc3', 'josef.peter@gmx.net', 2, 0, 'Muhammad'),
(12, 'Maryland', '21232f297a57a5a743894a0e4a801fc3', 'test@test.com', 3, 0, 'Justin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branchs`
--
ALTER TABLE `branchs`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`categories_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_replies`
--
ALTER TABLE `ticket_replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branchs`
--
ALTER TABLE `branchs`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `categories_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ticket_replies`
--
ALTER TABLE `ticket_replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;