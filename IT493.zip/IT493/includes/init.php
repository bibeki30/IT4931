<?php
define('HOST', $localhost);
define('USER', $username);
define('PASSWORD', $password);
define('DATABASE', $dbname);
require 'includes/Database.php';
require 'includes/Users.php';
require 'includes/Time.php';
require 'includes/Tickets.php';
$database = new Database;
$users = new Users;
$time = new Time;
$tickets = new Tickets;
?>
