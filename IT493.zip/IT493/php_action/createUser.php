<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$userName 	= $_POST['userName'];
	$upassword	= md5($_POST['upassword']);
	$uemail		= $_POST['uemail'];
	$branchName	= $_POST['branchName'];
	$manager = (isset($_POST['manager']) && $_POST['manager'] == 'Yes') ? 1:0;
		
	$sql = "INSERT INTO users (username, password,email,branch_id, manager) 
	VALUES ('$userName', '$upassword' , '$uemail', '$branchName', $manager)";
	if($connect->query($sql) === TRUE) {
		$valid['success'] = true;
		$valid['messages'] = "Successfully Added";	
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while adding the members";
	}
		
} // if in_array 		

$connect->close();

echo json_encode($valid);
 
