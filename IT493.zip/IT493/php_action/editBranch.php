<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$branchName = $_POST['editBranchName'];
  $branchStatus = $_POST['editBranchStatus']; 
  $branchId = $_POST['branchId'];

	$sql = "UPDATE branchs SET branch_name = '$branchName', branch_active = '$branchStatus' WHERE branch_id = '$branchId'";

	if($connect->query($sql) === TRUE) {
	 	$valid['success'] = true;
		$valid['messages'] = "Successfully Updated";	
	} else {
	 	$valid['success'] = false;
	 	$valid['messages'] = "Error while adding the members";
	}
	 
	$connect->close();

	echo json_encode($valid);
 
} // /if $_POST