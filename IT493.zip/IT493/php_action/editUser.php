<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {
	$edituserName = $_POST['edituserName'];
	$editPassword = md5($_POST['editPassword']);
	$userid 	  = $_POST['userid'];
	$branchid 	  = $_POST['editBranchName'];
	$manager = (isset($_POST['editManager']) && $_POST['editManager'] == 'Yes') ? 1:0;

				
	$sql = "UPDATE users SET username = '$edituserName', password = '$editPassword', branch_id = $branchid, manager = $manager WHERE user_id = $userid ";

	if($connect->query($sql) === TRUE) {
		$valid['success'] = true;
		$valid['messages'] = "Successfully Update";	
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while updating product info";
	}

} // /$_POST
	 
$connect->close();

echo json_encode($valid);
 
