<?php 	

require_once 'core.php';


$valid['success'] = array('success' => false, 'messages' => array());

$branchId = $_POST['branchId'];

if($branchId) { 

 $sql = "UPDATE branchs SET branch_status = 2 WHERE branch_id = {$branchId}";

 if($connect->query($sql) === TRUE) {
 	$valid['success'] = true;
	$valid['messages'] = "Successfully Removed";		
 } else {
 	$valid['success'] = false;
 	$valid['messages'] = "Error while remove the branch";
 }
 
 $connect->close();

 echo json_encode($valid);
 
} // /if $_POST