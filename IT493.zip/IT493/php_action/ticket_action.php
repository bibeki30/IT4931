<?php
require_once 'core.php';


// listTickets
if(!empty($_POST['action']) && $_POST['action'] == 'listTicket') {			 
		$sqlQuery = "SELECT t.id, t.uniqid, t.title, t.init_msg as message, t.date, t.last_reply, t.resolved, u.name as creater, b.branch_name as branch, u.manager, t.user, t.user_read, t.admin_read
			FROM tickets t 
			LEFT JOIN users u ON t.user = u.user_id 
			LEFT JOIN branchs b ON t.branch = b.branch_id";		
		$result = $connect->query($sqlQuery);
		$numRows = mysqli_num_rows($result);
		$ticketData = array();	
		while( $ticket = mysqli_fetch_assoc($result) ) {		
			$ticketRows = array();			
			$status = '';
			if($ticket['resolved'] == 0)	{
				$status = '<span class="label label-success">Open</span>';
			} else if($ticket['resolved'] == 1) {
				$status = '<span class="label label-danger">Closed</span>';
			}	
			$title = $ticket['title'];
			if((isset($_SESSION["manager"]) && ($_SESSION["manager"]!=1) && !$ticket['admin_read'] && $ticket['last_reply'] != $_SESSION["userid"]) || (($_SESSION["manager"]!=1) && !$ticket['user_read'] && $ticket['last_reply'] != $ticket['user'])) {
				$title = $this->getRepliedTitle($ticket['title']);			
			}
			$disbaled = '';
			if(($_SESSION["manager"]!=1)) {
				$disbaled = 'disabled';
			}			
			$ticketRows[] = $ticket['id'];
			$ticketRows[] = $ticket['uniqid'];
			$ticketRows[] = $title;
			$ticketRows[] = $ticket['branch'];
			$ticketRows[] = $ticket['creater']; 			
			$ticketRows[] = ""; //$time->ago($ticket['date']);
			$ticketRows[] = $status;
			$ticketRows[] = '<a href="view_ticket.php?id='.$ticket["uniqid"].'" class="btn btn-success btn-xs update">View Ticket</a>';	
			$ticketRows[] = '<button type="button" name="update" id="'.$ticket["id"].'" class="btn btn-warning btn-xs update" '.$disbaled.'>Edit</button>';
			$ticketRows[] = '<button type="button" name="delete" id="'.$ticket["id"].'" class="btn btn-danger btn-xs delete"  '.$disbaled.'>Close</button>';
			$ticketData[] = $ticketRows;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"  	=>  $numRows,
			"recordsFiltered" 	=> 	$numRows,
			"data"    			=> 	$ticketData
		);
		echo json_encode($output);
}

//createTicket
if(!empty($_POST['action']) && $_POST['action'] == 'createTicket') {
		if(!empty($_POST['subject']) && !empty($_POST['message'])) {                
			$date = new DateTime();
			$date = $date->getTimestamp();
			$uniqid = uniqid();                
			$message = strip_tags($_POST['subject']);              
			$queryInsert = "INSERT INTO tickets (uniqid, user, title, init_msg, branch, date, last_reply, user_read, admin_read, resolved) 
			VALUES('".$uniqid."', '".$_SESSION["userId"]."', '".$_POST['subject']."', '".$message."', '".$_SESSION['branchId']."', '".$date."', '".$_SESSION["userId"]."', 0, 0, '".$_POST['status']."')";			
			//mysqli_query($this->dbConnect, $queryInsert);
			$connect->query($queryInsert);
			echo 'success ' . $uniqid;
		} else {
			echo '<div class="alert error">Please fill in all fields.</div>';
		}
}

//getTicketdetails
if(!empty($_POST['action']) && $_POST['action'] == 'getTicketDetails') {
		if(isset($_POST['ticketId'])) {
			$sqlQuery = "
				SELECT * FROM tickets 
				WHERE id = '".$_POST["ticketId"]."'";
			//$result = mysqli_query($this->dbConnect, $sqlQuery);
			$result = $connect->query($sqlQuery);
			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			echo json_encode($row);
		}
}

// updateTicket
if(!empty($_POST['action']) && $_POST['action'] == 'updateTicket') {
		if($_POST['ticketId']) {	
			$updateQuery = "UPDATE tickets 
			SET title = '".$_POST["subject"]."', branch = '".$_POST["branch"]."', init_msg = '".$_POST["message"]."', resolved = '".$_POST["status"]."'
			WHERE id ='".$_POST["ticketId"]."'";
			//$isUpdated = mysqli_query($this->dbConnect, $updateQuery);
			$isUpdated = $connect->query($updateQuery);
		}	
}

// closeTicket
if(!empty($_POST['action']) && $_POST['action'] == 'closeTicket') {
		if($_POST["ticketId"]) {
			$sqlDelete = "UPDATE tickets SET resolved = '1'
				WHERE id = '".$_POST["ticketId"]."'";		
			//mysqli_query($this->dbConnect, $sqlDelete);	
			$connect->query($sqlDelete);
		}
}

// saveTicketReplies
if(!empty($_POST['action']) && $_POST['action'] == 'saveTicketReplies') {
		if($_POST['message']) {
			$date = new DateTime();
			$date = $date->getTimestamp();
			$queryInsert = "INSERT INTO ticket_replies (user, text, ticket_id, date) 
				VALUES('".$_SESSION['userId']."', '".$_POST['message']."', '".$_POST['ticketId']."', '".$date."')";
			//mysqli_query($this->dbConnect, , $queryInsert);
			$connect->query($queryInsert);
			$updateTicket = "UPDATE tickets SET last_reply = '".$_SESSION["userId"]."', user_read = '0', admin_read = '0' 
				WHERE id = '".$_POST['ticketId']."'";				
			//mysqli_query($this->dbConnect, $updateTicket);
			$connect->query($updateTicket);
		} 
}
?>